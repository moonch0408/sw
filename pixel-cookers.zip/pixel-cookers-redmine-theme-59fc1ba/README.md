Pixel Cookers Redmine Theme
===========================

[Pixel Cookers](http://pixel-cookers.github.com/redmine-theme/) is a nice, dark and blue theme for [Redmine](http://www.redmine.org).

* Screenshots: [Here](http://pixel-cookers.github.com/redmine-theme/)
* Author: [Ludovic Meyer](http://www.ludovicmeyer.com)
* Compatible with: Redmine 0.8.x, 1.x, 2.x & Redmine Trunk (see changelog and tags for compatibility)

### Install instructions :

Please follow the install instructions here : http://pixel-cookers.github.com/redmine-theme/

[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)